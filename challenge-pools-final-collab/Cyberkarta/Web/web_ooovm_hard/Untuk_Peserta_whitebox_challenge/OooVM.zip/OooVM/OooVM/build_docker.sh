#!/bin/bash
docker rm -f OooVM
docker build -t OooVM . && \
docker run --name=OooVM --rm -p1337:80 -it OooVM